const express = require('express');
const taskRoutes = require('./routes/tasks');
const { notFound, errorHandler } = require('./middleware/errors');

const app = express();
app.use(express.json());
app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/tasks', taskRoutes);
app.use(notFound);
app.use(errorHandler);

module.exports = app;
