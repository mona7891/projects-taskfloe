const STATUSES = ['todo', 'in-progress', 'done'];
const PRIORITIES = ['low', 'medium', 'high'];

// Returns an array of error messages (empty array = valid).
function validateTask(body, { partial = false } = {}) {
  const errors = [];
  const data = body || {};

  if (!partial || data.title !== undefined) {
    if (typeof data.title !== 'string' || data.title.trim() === '') {
      errors.push('title is required and must be a non-empty string');
    } else if (data.title.length > 120) {
      errors.push('title must be at most 120 characters');
    }
  }
  if (data.status !== undefined && !STATUSES.includes(data.status)) {
    errors.push(`status must be one of: ${STATUSES.join(', ')}`);
  }
  if (data.priority !== undefined && !PRIORITIES.includes(data.priority)) {
    errors.push(`priority must be one of: ${PRIORITIES.join(', ')}`);
  }
  if (data.dueDate !== undefined && Number.isNaN(Date.parse(data.dueDate))) {
    errors.push('dueDate must be a valid date');
  }
  return errors;
}

const validateBody = (options) => (req, res, next) => {
  const errors = validateTask(req.body, options);
  if (errors.length) return res.status(400).json({ errors });
  next();
};

module.exports = { validateTask, validateBody };
