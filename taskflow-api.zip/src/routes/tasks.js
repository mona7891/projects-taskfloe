const express = require('express');
const mongoose = require('mongoose');
const Task = require('../models/Task');
const { validateBody } = require('../middleware/validate');

const router = express.Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const checkId = (req, res, next) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: 'Invalid task id' });
  }
  next();
};

// GET /api/tasks?status=todo&priority=high&page=1&limit=10
router.get('/', wrap(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.priority) filter.priority = req.query.priority;

  const [tasks, total] = await Promise.all([
    Task.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Task.countDocuments(filter)
  ]);
  res.json({ data: tasks, page, limit, total, pages: Math.ceil(total / limit) });
}));

router.get('/:id', checkId, wrap(async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
}));

router.post('/', validateBody(), wrap(async (req, res) => {
  const task = await Task.create(req.body);
  res.status(201).json(task);
}));

router.put('/:id', checkId, validateBody({ partial: true }), wrap(async (req, res) => {
  const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
}));

router.delete('/:id', checkId, wrap(async (req, res) => {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.status(204).send();
}));

module.exports = router;
