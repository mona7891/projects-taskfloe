const { validateTask } = require('../src/middleware/validate');

describe('validateTask (unit)', () => {
  test('accepts a valid task', () => {
    expect(validateTask({ title: 'Write tests', status: 'todo', priority: 'high' })).toEqual([]);
  });
  test('rejects missing title', () => {
    expect(validateTask({})).toContain('title is required and must be a non-empty string');
  });
  test('rejects invalid status and priority', () => {
    const errors = validateTask({ title: 'x', status: 'later', priority: 'urgent' });
    expect(errors).toHaveLength(2);
  });
  test('rejects invalid dueDate', () => {
    expect(validateTask({ title: 'x', dueDate: 'not-a-date' })).toContain('dueDate must be a valid date');
  });
  test('partial updates do not require a title', () => {
    expect(validateTask({ status: 'done' }, { partial: true })).toEqual([]);
  });
});
