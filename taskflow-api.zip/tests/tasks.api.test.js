const request = require('supertest');

// Mock the Mongoose model so integration tests run without a database.
jest.mock('../src/models/Task');
const Task = require('../src/models/Task');
const app = require('../src/app');

const ID = '64b7f0c2a1b2c3d4e5f60718';
const chain = (result) => ({
  sort: () => ({ skip: () => ({ limit: () => Promise.resolve(result) }) })
});

afterEach(() => jest.resetAllMocks());

describe('Tasks API (integration)', () => {
  test('GET /health returns ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
  });

  test('GET /api/tasks returns paginated list', async () => {
    Task.find.mockReturnValue(chain([{ title: 'A' }, { title: 'B' }]));
    Task.countDocuments.mockResolvedValue(25);
    const res = await request(app).get('/api/tasks?page=2&limit=10&status=todo');
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ page: 2, limit: 10, total: 25, pages: 3 });
    expect(Task.find).toHaveBeenCalledWith({ status: 'todo' });
  });

  test('POST /api/tasks creates a task', async () => {
    Task.create.mockResolvedValue({ _id: ID, title: 'New', status: 'todo' });
    const res = await request(app).post('/api/tasks').send({ title: 'New' });
    expect(res.status).toBe(201);
    expect(res.body.title).toBe('New');
  });

  test('POST /api/tasks rejects invalid body with 400', async () => {
    const res = await request(app).post('/api/tasks').send({ status: 'bad' });
    expect(res.status).toBe(400);
    expect(res.body.errors.length).toBeGreaterThan(0);
    expect(Task.create).not.toHaveBeenCalled();
  });

  test('GET /api/tasks/:id returns 400 for malformed id', async () => {
    const res = await request(app).get('/api/tasks/123');
    expect(res.status).toBe(400);
  });

  test('GET /api/tasks/:id returns 404 when missing', async () => {
    Task.findById.mockResolvedValue(null);
    const res = await request(app).get(`/api/tasks/${ID}`);
    expect(res.status).toBe(404);
  });

  test('PUT /api/tasks/:id updates a task', async () => {
    Task.findByIdAndUpdate.mockResolvedValue({ _id: ID, title: 'New', status: 'done' });
    const res = await request(app).put(`/api/tasks/${ID}`).send({ status: 'done' });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('done');
  });

  test('DELETE /api/tasks/:id returns 204', async () => {
    Task.findByIdAndDelete.mockResolvedValue({ _id: ID });
    const res = await request(app).delete(`/api/tasks/${ID}`);
    expect(res.status).toBe(204);
  });

  test('unknown route returns 404', async () => {
    const res = await request(app).get('/nope');
    expect(res.status).toBe(404);
  });

  test('database failure returns 500 via error handler', async () => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
    Task.findById.mockRejectedValue(new Error('db down'));
    const res = await request(app).get(`/api/tasks/${ID}`);
    expect(res.status).toBe(500);
  });
});
